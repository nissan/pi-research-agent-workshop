# Pi Research Agent Proof

This is the participant starter project for the **Build Your First Specialist Agent** roadshow workshop.

## Goal

Start with a generic local research agent, then specialize it with exactly one layer:

1. a better prompt,
2. a small local tool,
3. a reusable skill,
4. custom domain information, or
5. a harness/settings customization.

Then compare the generic output with the specialized output and decide whether the specialized version could become a paid Reddi Agent Protocol specialist.

## Setup

```bash
npm install -g @earendil-works/pi-coding-agent
cd pi-research-agent-proof
pi
```

Inside Pi, run:

```text
/login
```

Then use the baseline prompt:

```text
Read the project instructions and generate the research brief requested in inputs/generic-brief-request.md. Use sources/source-notes.md. Write the result to outputs/research-brief-generic.md.
```

## Specialization challenge

Open `inputs/specialization-challenge.md`, choose one path, add your specialization, then rerun:

```text
Rerun the same research task, but include my specialization layer. Write the improved result to outputs/research-brief-specialized.md and write comparison notes to outputs/delta-notes.md.
```

## Safety note

Do not paste confidential client data, credentials, private keys, or personal information into this exercise. Use synthetic or redacted examples.
